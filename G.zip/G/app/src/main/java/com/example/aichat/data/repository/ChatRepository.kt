package com.example.aichat.data.repository

import com.example.aichat.data.local.ChatDao
import com.example.aichat.data.models.ChatMessage
import com.example.aichat.data.remote.*
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ChatRepository @Inject constructor(
    private val chatDao: ChatDao,
    private val geminiService: GeminiService
) {
    fun getAllMessages(): Flow<List<ChatMessage>> = chatDao.getAllMessages()

    suspend fun sendMessage(message: String, apiKey: String): String {
        // Save user message
        chatDao.insertMessage(ChatMessage(content = message, isUser = true))

        // Get AI response
        val request = GeminiRequest(
            contents = listOf(
                Content(
                    parts = listOf(
                        Part(text = message)
                    )
                )
            )
        )

        val response = geminiService.generateContent(apiKey, request)
        val aiResponse = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text
            ?: "Sorry, I couldn't generate a response."

        // Save AI response
        chatDao.insertMessage(ChatMessage(content = aiResponse, isUser = false))

        return aiResponse
    }

    suspend fun clearChat() = chatDao.clearAllMessages()
} 