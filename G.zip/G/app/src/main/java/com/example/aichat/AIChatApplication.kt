package com.example.aichat

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AIChatApplication : Application() 